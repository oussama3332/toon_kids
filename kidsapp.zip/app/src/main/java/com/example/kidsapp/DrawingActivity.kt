package com.example.kidsapp

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class DrawingActivity : AppCompatActivity() {

    private lateinit var selectedImageView: ImageView
    private lateinit var imageContainer: LinearLayout
    private lateinit var paint: Paint
    private var bitmap: Bitmap? = null
    private var canvas: Canvas? = null

    private val drawableIds = listOf(
        R.drawable.animal_cat,
        R.drawable.animal_dog,
        R.drawable.animal_lion,
        R.drawable.animal_elephant
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawing)

        selectedImageView = findViewById(R.id.selectedImage)
        imageContainer = findViewById(R.id.imageContainer)

        paint = Paint().apply {
            color = Color.RED
            strokeWidth = 10f
            style = Paint.Style.STROKE
        }

        for (drawableId in drawableIds) {
            val thumb = ImageView(this).apply {
                setImageDrawable(ContextCompat.getDrawable(this@DrawingActivity, drawableId))
                layoutParams = LinearLayout.LayoutParams(200, 200).apply {
                    marginEnd = 16
                }
                setOnClickListener {
                    val drawable = ContextCompat.getDrawable(this@DrawingActivity, drawableId)
                    val bmp = (drawable as BitmapDrawable).bitmap.copy(Bitmap.Config.ARGB_8888, true)
                    bitmap = bmp
                    canvas = Canvas(bmp)
                    selectedImageView.setImageBitmap(bmp)
                }
            }
            imageContainer.addView(thumb)
        }

        selectedImageView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_MOVE || event.action == MotionEvent.ACTION_DOWN) {
                canvas?.drawCircle(event.x, event.y, 20f, paint)
                selectedImageView.invalidate()
            }
            true
        }
    }
}
