package com.example.kidsapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CountrySelectionActivity : AppCompatActivity() {
    private var selectedCountry: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country_selection)

        val countryGrid = findViewById<GridLayout>(R.id.countryGrid)
        val nextButton = findViewById<Button>(R.id.nextButton)

        val countries = listOf(
            "المغرب" to R.drawable.flag_morocco,
            "الجزائر" to R.drawable.flag_algeria,
            "تونس" to R.drawable.flag_tunisia,
            "ليبيا" to R.drawable.flag_libya,
            "مصر" to R.drawable.flag_egypt,
            "السعودية" to R.drawable.flag_saudi,
            "الإمارات" to R.drawable.flag_uae,
            "أخرى" to R.drawable.flag_other
        )

        for ((name, flagRes) in countries) {
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 16, 16, 16)
                background = getDrawable(R.drawable.bg_card)
                setOnClickListener {
                    selectedCountry = name
                }
            }

            val img = ImageView(this).apply {
                setImageResource(flagRes)
                layoutParams = LinearLayout.LayoutParams(200, 150)
            }

            val text = TextView(this).apply {
                text = name
                textSize = 16f
                setTextColor(resources.getColor(R.color.black))
                textAlignment = TextView.TEXT_ALIGNMENT_CENTER
            }

            layout.addView(img)
            layout.addView(text)
            countryGrid.addView(layout)
        }

        nextButton.setOnClickListener {
            if (selectedCountry != null) {
                val intent = Intent(this, PersonalInfoActivity::class.java)
                intent.putExtra("selected_country", selectedCountry)
                startActivity(intent)
            }
        }
    }
}
