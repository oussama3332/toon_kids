package com.example.kidsapp
data class VideoItem(val title: String, val videoUrl: String)
