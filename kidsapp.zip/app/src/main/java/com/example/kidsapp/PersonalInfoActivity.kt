package com.example.kidsapp

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PersonalInfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_info)

        val fullNameEditText = findViewById<EditText>(R.id.fullNameEditText)
        val ageSpinner = findViewById<Spinner>(R.id.ageSpinner)
        val genderGroup = findViewById<RadioGroup>(R.id.genderRadioGroup)
        val nextButton = findViewById<Button>(R.id.nextToVideosButton)

        nextButton.setOnClickListener {
            val name = fullNameEditText.text.toString()
            val age = ageSpinner.selectedItem.toString()
            val genderId = genderGroup.checkedRadioButtonId

            if (name.isNotEmpty() && genderId != -1) {
                val gender = findViewById<RadioButton>(genderId).text.toString()
                val intent = Intent(this, VideoFeedActivity::class.java)
                intent.putExtra("full_name", name)
                intent.putExtra("age_range", age)
                intent.putExtra("gender", gender)
                startActivity(intent)
            } else {
                Toast.makeText(this, "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show()
            }
        }
    }
}