package com.example.kidsapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

class VideoFeedActivity : AppCompatActivity() {

    // Declare views with lateinit and nullable YouTubePlayer
    private lateinit var youtubePlayerView: YouTubePlayerView
    private var youTubePlayer: YouTubePlayer? = null
    private lateinit var nextFab: FloatingActionButton
    private lateinit var menuButton: ImageView
    private lateinit var parentControlButton: ImageView

    private val videoIds = listOf(
        "nHHOVlS8qJ8",  // Extracted YouTube video IDs
        "BHC78V8QCPA",
        "XK-HpBsbu-c"
    )
    private var currentVideoIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_feed)

        try {
            // Initialize views with null checks
            youtubePlayerView = findViewById(R.id.youtubePlayerView)
            nextFab = findViewById(R.id.nextFab)
            menuButton = findViewById(R.id.menuButton)
            parentControlButton = findViewById(R.id.parentControlButton)

            // Setup YouTube Player
            lifecycle.addObserver(youtubePlayerView)
            youtubePlayerView.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
                override fun onReady(player: YouTubePlayer) {
                    youTubePlayer = player
                    loadCurrentVideo()
                }
            })

            // Set click listeners
            nextFab.setOnClickListener {
                currentVideoIndex = (currentVideoIndex + 1) % videoIds.size
                loadCurrentVideo()
            }

            menuButton.setOnClickListener { view ->
                showCategoriesMenu(view)
            }

            parentControlButton.setOnClickListener {
                Toast.makeText(
                    this,
                    "Parent control feature coming soon",
                    Toast.LENGTH_SHORT
                ).show()
            }

        } catch (e: Exception) {
            Log.e("VideoFeedActivity", "Initialization error", e)
            Toast.makeText(this, "Error initializing player", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun loadCurrentVideo() {
        try {
            youTubePlayer?.loadVideo(videoIds[currentVideoIndex], 0f) ?: run {
                Toast.makeText(this, "Player not ready yet", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("VideoFeedActivity", "Video load error", e)
            Toast.makeText(this, "Error loading video", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCategoriesMenu(view: View) {
        try {
            val popup = PopupMenu(this, view)
            popup.menuInflater.inflate(R.menu.video_categories_menu, popup.menu)

            popup.setOnMenuItemClickListener { item: MenuItem ->
                when (item.itemId) {
                    R.id.menu_drawing -> {
                        startActivity(Intent(this, DrawingActivity::class.java))
                        true
                    }
                    R.id.menu_letters -> {
                        showToast("Letters section")
                        true
                    }
                    R.id.menu_numbers -> {
                        showToast("Numbers section")
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        } catch (e: Exception) {
            Log.e("VideoFeedActivity", "Menu error", e)
            Toast.makeText(this, "Menu error", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        youtubePlayerView.release()
    }
}